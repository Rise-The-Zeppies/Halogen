#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Halogen is a native macOS app. Run this file on your Mac, not on Linux or Windows."
  read -r -p "Press Return to close..." _ || true
  exit 1
fi

if ! command -v swiftc >/dev/null 2>&1; then
  echo "Swift isn't installed. Install Xcode or Apple's Command Line Tools, then run this file again."
  echo "Command Line Tools can be requested with: xcode-select --install"
  read -r -p "Press Return to close..." _ || true
  exit 1
fi

OS_MAJOR="$(sw_vers -productVersion | awk -F. '{print $1}')"
if [[ "$OS_MAJOR" -lt 12 ]]; then
  echo "Halogen targets macOS 12 Monterey or newer."
  read -r -p "Press Return to close..." _ || true
  exit 1
fi

export MACOSX_DEPLOYMENT_TARGET=12.0
APP="$ROOT/build/Halogen.app"

rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

swiftc -swift-version 5 -O \
  -framework SwiftUI \
  -framework AppKit \
  "$ROOT/Sources/HalogenApp.swift" \
  "$ROOT/Sources/ContentView.swift" \
  "$ROOT/Sources/GraphicsPreview.swift" \
  "$ROOT/Sources/HalogenInterpreter.swift" \
  -o "$APP/Contents/MacOS/Halogen"

cp "$ROOT/Info.plist" "$APP/Contents/Info.plist"
cp "$ROOT/AppIcon.icns" "$APP/Contents/Resources/AppIcon.icns"
/usr/bin/codesign --force --deep --sign - "$APP" >/dev/null 2>&1 || true

echo ""
echo "Built: $APP"
echo "Launching Halogen..."
open "$APP"
