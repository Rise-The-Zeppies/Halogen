import Foundation

struct GraphicCommand: Identifiable {
    enum Kind { case rectangle, circle, text, line, button }
    let id = UUID()
    var kind: Kind
    var x: Double = 0
    var y: Double = 0
    var width: Double = 0
    var height: Double = 0
    var radius: Double = 0
    var x2: Double = 0
    var y2: Double = 0
    var color: String = "#ffffff"
    var text: String = ""
    var fontSize: Double = 18
    var callback: String? = nil
}

struct HalogenRuntimeFailure: Error, LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

private enum HValue {
    case number(Double)
    case string(String)
    case boolean(Bool)
    case none

    var display: String {
        switch self {
        case .number(let value):
            if value.isFinite && value.rounded(.towardZero) == value { return String(format: "%.0f", value) }
            return String(value)
        case .string(let value): return value
        case .boolean(let value): return value ? "T" : "F"
        case .none: return ""
        }
    }

    var numeric: Double? {
        if case .number(let value) = self { return value }
        return nil
    }

    var boolean: Bool? {
        if case .boolean(let value) = self { return value }
        return nil
    }
}

private indirect enum HStatement {
    case simple(String, Int)
    case repeatBlock(String, [HStatement], Int)
    case conditional([(String?, [HStatement])], Int)
    case function(String, [String], [HStatement], Int)
}

private struct HFunction {
    let parameters: [String]
    let body: [HStatement]
}

private enum HFlow {
    case normal
    case returned(HValue)
}

final class HalogenInterpreter {
    private(set) var output = ""
    private(set) var graphics: [GraphicCommand] = []
    private(set) var graphicWidth = 640.0
    private(set) var graphicHeight = 400.0
    private(set) var graphicTitle = "HalogenUI"
    private(set) var graphicBackground = "#171923"

    private var scopes: [[String: HValue]] = [[:]]
    private var functions: [String: HFunction] = [:]
    private var clickFunction: String?
    private var currentLine = 1
    private var promptForInput: (String) -> String
    private var executionDepth = 0
    private let maximumRepeatCount = 10000

    init(promptForInput: @escaping (String) -> String) {
        self.promptForInput = promptForInput
    }

    func checkSyntax(source: String) throws {
        let lines = stripComments(source).enumerated().map { (index: $0.offset + 1, text: $0.element) }
        var parser = HParser(lines: lines)
        _ = try parser.parse()
    }

    func run(source: String) throws {
        output = ""
        graphics = []
        graphicWidth = 640
        graphicHeight = 400
        graphicTitle = "HalogenUI"
        graphicBackground = "#171923"
        scopes = [[:]]
        functions = [:]
        clickFunction = nil
        executionDepth = 0

        let lines = stripComments(source).enumerated().map { (index: $0.offset + 1, text: $0.element) }
        var parser = HParser(lines: lines)
        let statements = try parser.parse()
        _ = try execute(statements)
    }

    func invokeGraphicCallback(_ name: String?) {
        guard let name = name else { return }
        do {
            _ = try callFunction(name, arguments: [])
        } catch {
            append("\(error.localizedDescription)\n")
        }
    }

    func invokeCanvasClick() {
        invokeGraphicCallback(clickFunction)
    }

    private func append(_ text: String) {
        output += text
    }

    private func fail(_ message: String, line: Int? = nil) -> HalogenRuntimeFailure {
        HalogenRuntimeFailure(message: "Halogen error on line \(line ?? currentLine): \(message)")
    }

    private func stripComments(_ source: String) -> [String] {
        let inputLines = source.components(separatedBy: .newlines)
        var insideComment = false
        var result: [String] = []
        for line in inputLines {
            var outputLine = ""
            var index = line.startIndex
            var insideString = false
            var escaped = false
            while index < line.endIndex {
                if insideComment {
                    if line[index...].hasPrefix("\\#") {
                        insideComment = false
                        index = line.index(index, offsetBy: 2)
                    } else {
                        index = line.index(after: index)
                    }
                } else {
                    let character = line[index]
                    if escaped {
                        outputLine.append(character)
                        escaped = false
                        index = line.index(after: index)
                    } else if character == "\\" && insideString {
                        outputLine.append(character)
                        escaped = true
                        index = line.index(after: index)
                    } else if character == "\"" {
                        insideString.toggle()
                        outputLine.append(character)
                        index = line.index(after: index)
                    } else if !insideString && line[index...].hasPrefix("#/") {
                        insideComment = true
                        index = line.index(index, offsetBy: 2)
                    } else {
                        outputLine.append(character)
                        index = line.index(after: index)
                    }
                }
            }
            result.append(outputLine)
        }
        return result
    }

    private func execute(_ statements: [HStatement]) throws -> HFlow {
        executionDepth += 1
        defer { executionDepth -= 1 }
        if executionDepth > 100 { throw fail("Maximum function/block depth exceeded.") }

        for statement in statements {
            switch statement {
            case .simple(let text, let line):
                currentLine = line
                if let returnedValue = try executeSimple(text, line: line) { return .returned(returnedValue) }
            case .repeatBlock(let expression, let body, let line):
                currentLine = line
                let countValue = try evaluate(expression, line: line)
                guard let number = countValue.numeric, number >= 0, number.isFinite else {
                    throw fail("rpt needs a non-negative number.", line: line)
                }
                let count = Int(number.rounded(.towardZero))
                guard count <= maximumRepeatCount else {
                    throw fail("rpt is limited to \(maximumRepeatCount) repeats per loop.", line: line)
                }
                if count > 0 {
                    for _ in 0..<count {
                        let flow = try execute(body)
                        if case .returned = flow { return flow }
                    }
                }
            case .conditional(let branches, let line):
                currentLine = line
                for (condition, body) in branches {
                    if let condition = condition {
                        let value = try evaluate(condition, line: line)
                        if try truthValue(value, line: line) {
                            let flow = try execute(body)
                            if case .returned = flow { return flow }
                            break
                        }
                    } else {
                        let flow = try execute(body)
                        if case .returned = flow { return flow }
                        break
                    }
                }
            case .function(let name, let parameters, let body, _):
                functions[name] = HFunction(parameters: parameters, body: body)
            }
        }
        return .normal
    }

    private func executeSimple(_ rawText: String, line: Int) throws -> HValue? {
        let text = rawText.trimmingCharacters(in: .whitespacesAndNewlines)
        if text.isEmpty { return nil }
        if text == "import HalogenUI" { return nil }

        if text.hasPrefix("write(") && text.hasSuffix(")") {
            let inner = String(text.dropFirst(6).dropLast())
            let arguments = splitArguments(inner)
            let pieces = try arguments.map { try evaluate($0, line: line).display }
            append(pieces.joined() + "\n")
            return nil
        }

        if text.hasPrefix("ask(") && text.hasSuffix(")") {
            let inner = String(text.dropFirst(4).dropLast())
            let promptValue = try evaluate(inner, line: line)
            let prompt = promptValue.display
            let response = promptForInput(prompt)
            append(prompt + response + "\n")
            return nil
        }

        if text.hasPrefix("var(") {
            guard let close = text.firstIndex(of: ")") else { throw fail("Expected var(\"name\").", line: line) }
            let namePart = String(text[text.index(text.startIndex, offsetBy: 4)..<close]).trimmingCharacters(in: .whitespaces)
            let name = try parseQuotedName(namePart, type: "var", line: line)
            let rest = text[text.index(after: close)...].trimmingCharacters(in: .whitespaces)
            guard rest.hasPrefix("set ") else { throw fail("Use var(\"name\") set value.", line: line) }
            let valueText = String(rest.dropFirst(4)).trimmingCharacters(in: .whitespaces)
            let value = try evaluate(valueText, line: line)
            guard let number = value.numeric else { throw fail("var stores numbers; use var(\"\(name)\") set a number.", line: line) }
            try declare(name, value: .number(number), expectedType: "number", line: line)
            return nil
        }

        if text.hasPrefix("str(") {
            guard let close = text.firstIndex(of: ")") else { throw fail("Expected str(\"name\").", line: line) }
            let namePart = String(text[text.index(text.startIndex, offsetBy: 4)..<close]).trimmingCharacters(in: .whitespaces)
            let name = try parseQuotedName(namePart, type: "str", line: line)
            let rest = text[text.index(after: close)...].trimmingCharacters(in: .whitespaces)
            guard rest.hasPrefix("=") else { throw fail("Use str(\"name\") = text.", line: line) }
            let valueText = String(rest.dropFirst()).trimmingCharacters(in: .whitespaces)
            let value: HValue
            if isQuoted(valueText) {
                value = try evaluate(valueText, line: line)
            } else if let existing = lookup(valueText) {
                value = existing
            } else {
                value = .string(valueText)
            }
            guard case .string = value else { throw fail("str variables can only store text.", line: line) }
            try declare(name, value: value, expectedType: "string", line: line)
            return nil
        }

        if text.hasPrefix("bool(") {
            guard let close = text.firstIndex(of: ")") else { throw fail("Expected bool(\"name\").", line: line) }
            let namePart = String(text[text.index(text.startIndex, offsetBy: 5)..<close]).trimmingCharacters(in: .whitespaces)
            let name = try parseQuotedName(namePart, type: "bool", line: line)
            let rest = text[text.index(after: close)...].trimmingCharacters(in: .whitespaces)
            guard rest.hasPrefix("=") else { throw fail("Use bool(\"name\") = T or F.", line: line) }
            let valueText = String(rest.dropFirst()).trimmingCharacters(in: .whitespaces)
            let value: HValue
            if valueText.caseInsensitiveCompare("T") == .orderedSame || valueText.lowercased() == "true" {
                value = .boolean(true)
            } else if valueText.caseInsensitiveCompare("F") == .orderedSame || valueText.lowercased() == "false" {
                value = .boolean(false)
            } else if let existing = lookup(valueText), existing.boolean != nil {
                value = existing
            } else {
                throw fail("Boolean values must be T/t or F/f.", line: line)
            }
            try declare(name, value: value, expectedType: "boolean", line: line)
            return nil
        }

        if text.hasSuffix(" get") {
            let name = String(text.dropLast(4)).trimmingCharacters(in: .whitespaces)
            guard isIdentifier(name) else { throw fail("Use a variable name followed by get.", line: line) }
            guard let value = lookup(name) else { throw fail("Variable '\(name)' has not been declared.", line: line) }
            append(value.display + "\n")
            return nil
        }

        if text.hasPrefix("HalogenUI.") {
            try executeUICommand(text, line: line)
            return nil
        }

        if text.hasPrefix("return ") {
            let valueText = String(text.dropFirst(7)).trimmingCharacters(in: .whitespaces)
            return try evaluate(valueText, line: line)
        }

        if let call = parseFunctionCall(text) {
            let values = try call.arguments.map { try evaluate($0, line: line) }
            _ = try callFunction(call.name, arguments: values)
            return nil
        }

        throw fail("I don't recognize '\(text)'.", line: line)
    }

    private func executeUICommand(_ text: String, line: Int) throws {
        guard let opening = text.firstIndex(of: "("), text.hasSuffix(")") else {
            throw fail("Expected HalogenUI.command(...).", line: line)
        }
        let name = String(text[text.index(text.startIndex, offsetBy: "HalogenUI.".count)..<opening])
        let argumentText = String(text[text.index(after: opening)..<text.index(before: text.endIndex)])
        let rawArguments = splitArguments(argumentText)
        let args = try rawArguments.enumerated().map { index, raw -> HValue in
            let trimmed = raw.trimmingCharacters(in: .whitespaces)
            if (name == "button" && index == 5) || (name == "on_click" && index == 0) {
                if isQuoted(trimmed) { return try evaluate(trimmed, line: line) }
                return .string(trimmed)
            }
            return try evaluate(trimmed, line: line)
        }
        func need(_ index: Int) throws -> HValue {
            guard index < args.count else { throw fail("HalogenUI.\(name) is missing an argument.", line: line) }
            return args[index]
        }
        func number(_ index: Int) throws -> Double {
            guard let n = try need(index).numeric else { throw fail("HalogenUI.\(name) expects a number at argument \(index + 1).", line: line) }
            return n
        }
        func string(_ index: Int) throws -> String { try need(index).display }

        switch name {
        case "window":
            graphicTitle = try string(0)
            graphicWidth = max(160, min(1600, try number(1)))
            graphicHeight = max(120, min(1200, try number(2)))
            if args.count > 3 { graphicBackground = try string(3) }
            graphics.removeAll()
        case "fill", "background":
            graphicBackground = try string(0)
            graphics.removeAll()
        case "rect", "rectangle":
            let color = try string(0)
            let x = try number(1), y = try number(2), w = try number(3), h = try number(4)
            graphics.append(GraphicCommand(kind: .rectangle, x: x, y: y, width: w, height: h, color: color))
        case "circle":
            let color = try string(0)
            let x = try number(1), y = try number(2), radius = try number(3)
            graphics.append(GraphicCommand(kind: .circle, x: x, y: y, radius: radius, color: color))
        case "text":
            let value = try string(0), x = try number(1), y = try number(2), color = try string(3), size = try number(4)
            graphics.append(GraphicCommand(kind: .text, x: x, y: y, color: color, text: value, fontSize: size))
        case "line":
            let color = try string(0), x1 = try number(1), y1 = try number(2), x2 = try number(3), y2 = try number(4)
            let width = args.count > 5 ? try number(5) : 2
            graphics.append(GraphicCommand(kind: .line, x: x1, y: y1, width: width, x2: x2, y2: y2, color: color))
        case "button":
            let label = try string(0), x = try number(1), y = try number(2), w = try number(3), h = try number(4)
            let callback = args.count > 5 ? try string(5) : nil
            graphics.append(GraphicCommand(kind: .button, x: x, y: y, width: w, height: h, color: "#2d9ea8", text: label, fontSize: 15, callback: callback))
        case "on_click":
            clickFunction = try string(0)
        case "run", "update":
            // HalogenUI's event loop is hosted by the editor app; these remain valid no-op lifecycle calls.
            return
        case "close":
            graphics.removeAll()
        case "width":
            append(HValue.number(graphicWidth).display + "\n")
        case "height":
            append(HValue.number(graphicHeight).display + "\n")
        case "is_open":
            append("T\n")
        default:
            throw fail("Unknown HalogenUI command '\(name)'.", line: line)
        }
    }

    private func parseQuotedName(_ text: String, type: String, line: Int) throws -> String {
        guard isQuoted(text) else { throw fail("The variable name in \(type)(...) must be in quotation marks.", line: line) }
        let name = String(text.dropFirst().dropLast())
        guard isIdentifier(name) else { throw fail("'\(name)' is not a valid variable name.", line: line) }
        return name
    }

    private func declare(_ name: String, value: HValue, expectedType: String, line: Int) throws {
        if let existing = lookup(name), typeName(existing) != expectedType {
            throw fail("Variable '\(name)' was already declared as a \(typeName(existing)); it cannot become a \(expectedType).", line: line)
        }
        assign(name, value: value)
    }

    private func typeName(_ value: HValue) -> String {
        switch value {
        case .number: return "number"
        case .string: return "string"
        case .boolean: return "boolean"
        case .none: return "empty value"
        }
    }

    private func lookup(_ name: String) -> HValue? {
        for scope in scopes.reversed() {
            if let value = scope[name] { return value }
        }
        return nil
    }

    private func assign(_ name: String, value: HValue) {
        for index in scopes.indices.reversed() {
            if scopes[index][name] != nil {
                scopes[index][name] = value
                return
            }
        }
        scopes[scopes.count - 1][name] = value
    }

    private func evaluate(_ expression: String, line: Int) throws -> HValue {
        do {
            var parser = try HExpressionParser(expression: expression, lookup: { [weak self] in self?.lookup($0) })
            return try parser.parse()
        } catch {
            if let failure = error as? HalogenRuntimeFailure { throw failure }
            throw fail(error.localizedDescription, line: line)
        }
    }

    private func truthValue(_ value: HValue, line: Int) throws -> Bool {
        switch value {
        case .boolean(let value): return value
        default: throw fail("Conditions must evaluate to T or F.", line: line)
        }
    }

    private func callFunction(_ name: String, arguments: [HValue]) throws -> HValue {
        guard let function = functions[name] else { throw fail("Function '\(name)' has not been defined.") }
        guard arguments.count == function.parameters.count else {
            throw fail("Function '\(name)' expects \(function.parameters.count) argument(s), received \(arguments.count).")
        }
        var local: [String: HValue] = [:]
        for (parameter, value) in zip(function.parameters, arguments) { local[parameter] = value }
        scopes.append(local)
        defer { scopes.removeLast() }
        let flow = try execute(function.body)
        if case .returned(let value) = flow { return value }
        return .none
    }

    private func parseFunctionCall(_ text: String) -> (name: String, arguments: [String])? {
        guard let open = text.firstIndex(of: "("), text.hasSuffix(")") else { return nil }
        let name = String(text[..<open]).trimmingCharacters(in: .whitespaces)
        guard isIdentifier(name) else { return nil }
        let inner = String(text[text.index(after: open)..<text.index(before: text.endIndex)])
        return (name, inner.trimmingCharacters(in: .whitespaces).isEmpty ? [] : splitArguments(inner))
    }

    private func splitArguments(_ text: String) -> [String] {
        var output: [String] = []
        var current = ""
        var depth = 0
        var quoted = false
        var escaped = false
        for character in text {
            if escaped { current.append(character); escaped = false; continue }
            if character == "\\" && quoted { current.append(character); escaped = true; continue }
            if character == "\"" { quoted.toggle(); current.append(character); continue }
            if !quoted {
                if character == "(" { depth += 1 }
                if character == ")" { depth -= 1 }
                if character == "," && depth == 0 { output.append(current.trimmingCharacters(in: .whitespaces)); current = ""; continue }
            }
            current.append(character)
        }
        if !current.trimmingCharacters(in: .whitespaces).isEmpty { output.append(current.trimmingCharacters(in: .whitespaces)) }
        return output
    }

    private func isQuoted(_ value: String) -> Bool {
        value.count >= 2 && value.first == "\"" && value.last == "\""
    }

    private func isIdentifier(_ value: String) -> Bool {
        guard let first = value.first, first.isLetter || first == "_" else { return false }
        return value.dropFirst().allSatisfy { $0.isLetter || $0.isNumber || $0 == "_" }
    }
}

private struct HParser {
    let lines: [(index: Int, text: String)]
    var cursor = 0

    mutating func parse() throws -> [HStatement] {
        let result = try parseBlock(stopAt: [])
        if cursor < lines.count {
            let extra = lines[cursor]
            throw HalogenRuntimeFailure(message: "Halogen error on line \(extra.index): Unexpected '\(extra.text.trimmingCharacters(in: .whitespaces))'.")
        }
        return result
    }

    private mutating func parseBlock(stopAt stopWords: Set<String>) throws -> [HStatement] {
        var statements: [HStatement] = []
        while cursor < lines.count {
            let entry = lines[cursor]
            let text = entry.text.trimmingCharacters(in: .whitespacesAndNewlines)
            if text.isEmpty { cursor += 1; continue }
            if isStop(text, words: stopWords) { return statements }

            if text.hasPrefix("if ") && text.hasSuffix(":") {
                let condition = String(text.dropFirst(3).dropLast()).trimmingCharacters(in: .whitespaces)
                cursor += 1
                var branches: [(String?, [HStatement])] = []
                let firstBody = try parseBlock(stopAt: ["elif", "else", "end"])
                branches.append((condition, firstBody))
                while cursor < lines.count {
                    let marker = lines[cursor].text.trimmingCharacters(in: .whitespacesAndNewlines)
                    if marker.hasPrefix("elif ") && marker.hasSuffix(":") {
                        let nextCondition = String(marker.dropFirst(5).dropLast()).trimmingCharacters(in: .whitespaces)
                        cursor += 1
                        branches.append((nextCondition, try parseBlock(stopAt: ["elif", "else", "end"])))
                    } else { break }
                }
                if cursor < lines.count && lines[cursor].text.trimmingCharacters(in: .whitespacesAndNewlines) == "else:" {
                    cursor += 1
                    branches.append((nil, try parseBlock(stopAt: ["end"])))
                }
                try consumeEnd(line: entry.index)
                statements.append(.conditional(branches, entry.index))
                continue
            }

            if text.hasPrefix("rpt ") && text.hasSuffix(":") {
                let expression = String(text.dropFirst(4).dropLast()).trimmingCharacters(in: .whitespaces)
                cursor += 1
                let body = try parseBlock(stopAt: ["end"])
                try consumeEnd(line: entry.index)
                statements.append(.repeatBlock(expression, body, entry.index))
                continue
            }

            if text.hasPrefix("def ") && text.hasSuffix(":") {
                let declaration = String(text.dropFirst(4).dropLast()).trimmingCharacters(in: .whitespaces)
                guard let open = declaration.firstIndex(of: "("), declaration.hasSuffix(")") else {
                    throw HalogenRuntimeFailure(message: "Halogen error on line \(entry.index): Use def name(parameters):.")
                }
                let name = String(declaration[..<open]).trimmingCharacters(in: .whitespaces)
                guard validIdentifier(name) else { throw HalogenRuntimeFailure(message: "Halogen error on line \(entry.index): Invalid function name '\(name)'.") }
                let parameterText = String(declaration[declaration.index(after: open)..<declaration.index(before: declaration.endIndex)])
                let parameters = parameterText.trimmingCharacters(in: .whitespaces).isEmpty ? [] : parameterText.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }
                guard parameters.allSatisfy(validIdentifier) else { throw HalogenRuntimeFailure(message: "Halogen error on line \(entry.index): Invalid function parameter.") }
                cursor += 1
                let body = try parseBlock(stopAt: ["end"])
                try consumeEnd(line: entry.index)
                statements.append(.function(name, parameters, body, entry.index))
                continue
            }

            if text == "end" || text == "else:" || text.hasPrefix("elif ") {
                throw HalogenRuntimeFailure(message: "Halogen error on line \(entry.index): Unexpected block marker '\(text)'.")
            }
            statements.append(.simple(text, entry.index))
            cursor += 1
        }
        return statements
    }

    private func isStop(_ text: String, words: Set<String>) -> Bool {
        if words.contains("end") && text == "end" { return true }
        if words.contains("else") && text == "else:" { return true }
        if words.contains("elif") && text.hasPrefix("elif ") { return true }
        return false
    }

    private mutating func consumeEnd(line: Int) throws {
        guard cursor < lines.count, lines[cursor].text.trimmingCharacters(in: .whitespacesAndNewlines) == "end" else {
            throw HalogenRuntimeFailure(message: "Halogen error on line \(line): Block is missing its closing 'end'.")
        }
        cursor += 1
    }

    private func validIdentifier(_ value: String) -> Bool {
        guard let first = value.first, first.isLetter || first == "_" else { return false }
        return value.dropFirst().allSatisfy { $0.isLetter || $0.isNumber || $0 == "_" }
    }
}

private enum HToken {
    case number(Double)
    case string(String)
    case identifier(String)
    case operation(String)
    case leftParen
    case rightParen
}

private struct HExpressionParser {
    private let tokens: [HToken]
    private var cursor = 0
    private let lookup: (String) -> HValue?

    init(expression: String, lookup: @escaping (String) -> HValue?) throws {
        self.tokens = try Self.tokenize(expression)
        self.lookup = lookup
    }

    mutating func parse() throws -> HValue {
        let value = try parseOr()
        if cursor < tokens.count { throw HalogenRuntimeFailure(message: "Unexpected token at end of expression.") }
        return value
    }

    private mutating func parseOr() throws -> HValue {
        var lhs = try parseAnd()
        while matchOperation("or") {
            let rhs = try parseAnd()
            guard let l = lhs.boolean, let r = rhs.boolean else { throw HalogenRuntimeFailure(message: "'or' requires Boolean values.") }
            lhs = .boolean(l || r)
        }
        return lhs
    }

    private mutating func parseAnd() throws -> HValue {
        var lhs = try parseEquality()
        while matchOperation("and") {
            let rhs = try parseEquality()
            guard let l = lhs.boolean, let r = rhs.boolean else { throw HalogenRuntimeFailure(message: "'and' requires Boolean values.") }
            lhs = .boolean(l && r)
        }
        return lhs
    }

    private mutating func parseEquality() throws -> HValue {
        var lhs = try parseComparison()
        while true {
            if matchOperation("==") { let rhs = try parseComparison(); lhs = .boolean(equal(lhs, rhs)) }
            else if matchOperation("!=") { let rhs = try parseComparison(); lhs = .boolean(!equal(lhs, rhs)) }
            else { return lhs }
        }
    }

    private mutating func parseComparison() throws -> HValue {
        var lhs = try parseAdditive()
        while true {
            if matchOperation(">") { let rhs = try parseAdditive(); lhs = .boolean(try compare(lhs, rhs, op: ">")) }
            else if matchOperation(">=") { let rhs = try parseAdditive(); lhs = .boolean(try compare(lhs, rhs, op: ">=")) }
            else if matchOperation("<") { let rhs = try parseAdditive(); lhs = .boolean(try compare(lhs, rhs, op: "<")) }
            else if matchOperation("<=") { let rhs = try parseAdditive(); lhs = .boolean(try compare(lhs, rhs, op: "<=")) }
            else { return lhs }
        }
    }

    private mutating func parseAdditive() throws -> HValue {
        var lhs = try parseMultiplicative()
        while true {
            if matchOperation("+") {
                let rhs = try parseMultiplicative()
                if let l = lhs.numeric, let r = rhs.numeric { lhs = .number(l + r) }
                else { lhs = .string(lhs.display + rhs.display) }
            } else if matchOperation("-") {
                let rhs = try parseMultiplicative()
                guard let l = lhs.numeric, let r = rhs.numeric else { throw HalogenRuntimeFailure(message: "Subtraction requires numbers.") }
                lhs = .number(l - r)
            } else { return lhs }
        }
    }

    private mutating func parseMultiplicative() throws -> HValue {
        var lhs = try parsePower()
        while true {
            if matchOperation("*") { let rhs = try parsePower(); lhs = .number(try number(lhs) * number(rhs)) }
            else if matchOperation("/") {
                let rhs = try parsePower(), divisor = try number(rhs)
                if divisor == 0 { throw HalogenRuntimeFailure(message: "Cannot divide by zero.") }
                lhs = .number(try number(lhs) / divisor)
            } else if matchOperation("//") {
                let rhs = try parsePower(), divisor = try number(rhs)
                if divisor == 0 { throw HalogenRuntimeFailure(message: "Cannot divide by zero.") }
                lhs = .number(floor(try number(lhs) / divisor))
            } else if matchOperation("%") {
                let rhs = try parsePower(), divisor = try number(rhs)
                if divisor == 0 { throw HalogenRuntimeFailure(message: "Cannot divide by zero.") }
                lhs = .number(try number(lhs).truncatingRemainder(dividingBy: divisor))
            } else { return lhs }
        }
    }

    private mutating func parsePower() throws -> HValue {
        let lhs = try parseUnary()
        if matchOperation("**") { return .number(pow(try number(lhs), try number(parsePower()))) }
        return lhs
    }

    private mutating func parseUnary() throws -> HValue {
        if matchOperation("-") { return .number(-(try number(parseUnary()))) }
        if matchOperation("+") { return .number(try number(parseUnary())) }
        if matchOperation("not") {
            let value = try parseUnary()
            guard let boolean = value.boolean else { throw HalogenRuntimeFailure(message: "'not' requires a Boolean.") }
            return .boolean(!boolean)
        }
        return try parsePrimary()
    }

    private mutating func parsePrimary() throws -> HValue {
        guard cursor < tokens.count else { throw HalogenRuntimeFailure(message: "Expected a value.") }
        let token = tokens[cursor]
        cursor += 1
        switch token {
        case .number(let value): return .number(value)
        case .string(let value): return .string(value)
        case .identifier(let name):
            if name == "T" || name == "t" || name.lowercased() == "true" { return .boolean(true) }
            if name == "F" || name == "f" || name.lowercased() == "false" { return .boolean(false) }
            guard let value = lookup(name) else { throw HalogenRuntimeFailure(message: "Variable '\(name)' has not been declared.") }
            return value
        case .leftParen:
            let value = try parseOr()
            guard cursor < tokens.count, case .rightParen = tokens[cursor] else { throw HalogenRuntimeFailure(message: "Missing closing parenthesis.") }
            cursor += 1
            return value
        case .rightParen: throw HalogenRuntimeFailure(message: "Unexpected closing parenthesis.")
        case .operation(let operation): throw HalogenRuntimeFailure(message: "Unexpected operator '\(operation)'.")
        }
    }

    private mutating func matchOperation(_ expected: String) -> Bool {
        guard cursor < tokens.count, case .operation(let value) = tokens[cursor], value == expected else { return false }
        cursor += 1
        return true
    }

    private func number(_ value: HValue) throws -> Double {
        guard let number = value.numeric else { throw HalogenRuntimeFailure(message: "Math operators require numbers.") }
        return number
    }

    private func equal(_ left: HValue, _ right: HValue) -> Bool {
        switch (left, right) {
        case (.number(let a), .number(let b)): return a == b
        case (.string(let a), .string(let b)): return a == b
        case (.boolean(let a), .boolean(let b)): return a == b
        case (.none, .none): return true
        default: return false
        }
    }

    private func compare(_ left: HValue, _ right: HValue, op: String) throws -> Bool {
        if let a = left.numeric, let b = right.numeric {
            switch op { case ">": return a > b; case ">=": return a >= b; case "<": return a < b; default: return a <= b }
        }
        if case .string(let a) = left, case .string(let b) = right {
            switch op { case ">": return a > b; case ">=": return a >= b; case "<": return a < b; default: return a <= b }
        }
        throw HalogenRuntimeFailure(message: "Comparison requires two numbers or two strings.")
    }

    private static func tokenize(_ expression: String) throws -> [HToken] {
        let chars = Array(expression)
        var result: [HToken] = []
        var i = 0
        while i < chars.count {
            let c = chars[i]
            if c.isWhitespace { i += 1; continue }
            if c == "\"" {
                i += 1
                var value = ""
                var closed = false
                while i < chars.count {
                    if chars[i] == "\\" && i + 1 < chars.count {
                        let next = chars[i + 1]
                        switch next { case "n": value.append("\n"); case "t": value.append("\t"); case "\"": value.append("\""); case "\\": value.append("\\"); default: value.append(next) }
                        i += 2
                    } else if chars[i] == "\"" { closed = true; i += 1; break }
                    else { value.append(chars[i]); i += 1 }
                }
                guard closed else { throw HalogenRuntimeFailure(message: "Text string is missing a closing quotation mark.") }
                result.append(.string(value)); continue
            }
            if c.isNumber || (c == "." && i + 1 < chars.count && chars[i + 1].isNumber) {
                let start = i
                i += 1
                while i < chars.count && (chars[i].isNumber || chars[i] == ".") { i += 1 }
                guard let number = Double(String(chars[start..<i])) else { throw HalogenRuntimeFailure(message: "Invalid number.") }
                result.append(.number(number)); continue
            }
            if c.isLetter || c == "_" {
                let start = i; i += 1
                while i < chars.count && (chars[i].isLetter || chars[i].isNumber || chars[i] == "_") { i += 1 }
                let name = String(chars[start..<i])
                if ["and", "or", "not"].contains(name) { result.append(.operation(name)) }
                else { result.append(.identifier(name)) }
                continue
            }
            if c == "(" { result.append(.leftParen); i += 1; continue }
            if c == ")" { result.append(.rightParen); i += 1; continue }
            if i + 1 < chars.count {
                let two = String(chars[i...i+1])
                if ["==", "!=", "<=", ">=", "//", "**"].contains(two) { result.append(.operation(two)); i += 2; continue }
            }
            if ["+", "-", "*", "/", "%", ">", "<"].contains(c) { result.append(.operation(String(c))); i += 1; continue }
            throw HalogenRuntimeFailure(message: "Unexpected character '\(c)' in expression.")
        }
        return result
    }
}
