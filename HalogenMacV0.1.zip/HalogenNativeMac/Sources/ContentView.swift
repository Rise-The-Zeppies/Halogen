import AppKit
import SwiftUI

final class HalogenIDEModel: ObservableObject {
    @Published var source: String = "#/ Welcome to Halogen! \\#\nwrite(\"Welcome to Halogen!\")\n\nvar(\"x\") set 5\nx get\n\nrpt 3:\n    write(\"Halogen is running.\")\nend\n"
    @Published var console: String = "Ready. Open or write a .hg file, then press Run.\n"
    @Published var graphics: [GraphicCommand] = []
    @Published var graphicsWidth: Double = 640
    @Published var graphicsHeight: Double = 400
    @Published var graphicsTitle: String = "HalogenUI Preview"
    @Published var graphicsBackground: String = "#171923"
    @Published var displayedFilename: String = "Untitled.hg"
    @Published var hasUnsavedChanges = false

    private(set) var currentFileURL: URL?
    private var interpreter: HalogenInterpreter?

    func sourceChanged() { hasUnsavedChanges = true }

    func runProgram() {
        let runner = HalogenInterpreter(promptForInput: { prompt in
            Self.showInputPrompt(prompt)
        })
        do {
            try runner.run(source: source)
            interpreter = runner
            console = runner.output.isEmpty ? "Program finished successfully.\n" : runner.output
            refreshGraphics(from: runner)
        } catch {
            interpreter = runner
            console = runner.output + error.localizedDescription + "\n"
            refreshGraphics(from: runner)
        }
    }

    func checkProgram() {
        let checker = HalogenInterpreter(promptForInput: { _ in "" })
        do {
            try checker.checkSyntax(source: source)
            console = "Block structure looks good. Run the program to validate commands and expressions.\n"
        } catch {
            console = error.localizedDescription + "\n"
        }
    }

    func clearConsole() { console = "" }

    func openFile() {
        let panel = NSOpenPanel()
        panel.title = "Open Halogen File"
        panel.allowedFileTypes = ["hg"]
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            source = try String(contentsOf: url, encoding: .utf8)
            currentFileURL = url
            displayedFilename = url.lastPathComponent
            hasUnsavedChanges = false
            console = "Opened \(url.lastPathComponent).\n"
            graphics.removeAll()
        } catch {
            console = "Couldn't open file: \(error.localizedDescription)\n"
        }
    }

    func saveFile() {
        if let url = currentFileURL {
            writeFile(to: url)
        } else {
            saveFileAs()
        }
    }

    func saveFileAs() {
        let panel = NSSavePanel()
        panel.title = "Save Halogen File"
        panel.nameFieldStringValue = displayedFilename.hasSuffix(".hg") ? displayedFilename : displayedFilename + ".hg"
        panel.allowedFileTypes = ["hg"]
        guard panel.runModal() == .OK, let url = panel.url else { return }
        writeFile(to: url)
    }

    func newFile() {
        source = "write(\"Hello from Halogen!\")\n"
        currentFileURL = nil
        displayedFilename = "Untitled.hg"
        hasUnsavedChanges = false
        graphics.removeAll()
        console = "New Halogen file.\n"
    }

    func graphicButtonClicked(_ command: GraphicCommand) {
        guard let callback = command.callback else {
            console += "Clicked: \(command.text)\n"
            return
        }
        interpreter?.invokeGraphicCallback(callback)
        if let interpreter = interpreter { console = interpreter.output }
        refreshGraphicsFromCurrentInterpreter()
    }

    func graphicsCanvasClicked() {
        interpreter?.invokeCanvasClick()
        if let interpreter = interpreter { console = interpreter.output }
        refreshGraphicsFromCurrentInterpreter()
    }

    private func refreshGraphicsFromCurrentInterpreter() {
        if let interpreter = interpreter { refreshGraphics(from: interpreter) }
    }

    private func refreshGraphics(from runner: HalogenInterpreter) {
        graphics = runner.graphics
        graphicsWidth = runner.graphicWidth
        graphicsHeight = runner.graphicHeight
        graphicsTitle = runner.graphicTitle
        graphicsBackground = runner.graphicBackground
    }

    private func writeFile(to url: URL) {
        do {
            try source.write(to: url, atomically: true, encoding: .utf8)
            currentFileURL = url
            displayedFilename = url.lastPathComponent
            hasUnsavedChanges = false
            console = "Saved \(url.lastPathComponent).\n"
        } catch {
            console = "Couldn't save file: \(error.localizedDescription)\n"
        }
    }

    private static func showInputPrompt(_ prompt: String) -> String {
        let alert = NSAlert()
        alert.messageText = prompt.isEmpty ? "Halogen input" : prompt
        alert.informativeText = "Enter a value for ask()."
        alert.addButton(withTitle: "Submit")
        alert.addButton(withTitle: "Cancel")
        let field = NSTextField(frame: NSRect(x: 0, y: 0, width: 300, height: 24))
        field.placeholderString = "Type here"
        alert.accessoryView = field
        alert.window.initialFirstResponder = field
        return alert.runModal() == .alertFirstButtonReturn ? field.stringValue : ""
    }
}

struct ContentView: View {
    @StateObject private var model = HalogenIDEModel()
    @State private var rightPanel: RightPanel = .graphics

    enum RightPanel: String, CaseIterable { case graphics = "HalogenUI", console = "Console" }

    var body: some View {
        VStack(spacing: 0) {
            header
            Rectangle().fill(Color.white.opacity(0.07)).frame(height: 1)
            HStack(spacing: 0) {
                VStack(spacing: 0) {
                    sectionHeader(title: "EDITOR", subtitle: model.displayedFilename + (model.hasUnsavedChanges ? " •" : ""))
                    CodeEditorView(text: $model.source, onEdit: { model.sourceChanged() })
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                .frame(minWidth: 500, maxWidth: .infinity, maxHeight: .infinity)

                Rectangle().fill(Color.white.opacity(0.08)).frame(width: 1)

                VStack(spacing: 0) {
                    HStack(spacing: 5) {
                        ForEach(RightPanel.allCases, id: \.self) { panel in
                            Button(action: { rightPanel = panel }) {
                                Text(panel.rawValue)
                                    .font(.system(size: 12, weight: .semibold))
                                    .foregroundColor(rightPanel == panel ? Color.white : Color.white.opacity(0.55))
                                    .padding(.horizontal, 13)
                                    .padding(.vertical, 8)
                                    .background(rightPanel == panel ? Color.white.opacity(0.11) : Color.clear)
                                    .cornerRadius(6)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                        Spacer()
                        if rightPanel == .console {
                            Button("Clear") { model.clearConsole() }
                                .buttonStyle(QuietButtonStyle())
                        }
                    }
                    .padding(.horizontal, 12)
                    .frame(height: 42)
                    .background(Color(red: 0.12, green: 0.13, blue: 0.15))

                    if rightPanel == .graphics {
                        GraphicsPreview(model: model)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                    } else {
                        ConsoleView(text: model.console)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                    }
                }
                .frame(width: 410)
            }
            Rectangle().fill(Color.white.opacity(0.07)).frame(height: 1)
            HStack(spacing: 8) {
                Circle().fill(Color(red: 0.28, green: 0.82, blue: 0.62)).frame(width: 7, height: 7)
                Text("HALOGEN v0.1 • NATIVE MAC APP")
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundColor(Color.white.opacity(0.46))
                Spacer()
                Text(".hg")
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundColor(Color.white.opacity(0.46))
            }
            .padding(.horizontal, 15)
            .frame(height: 26)
            .background(Color(red: 0.10, green: 0.11, blue: 0.13))
        }
        .background(Color(red: 0.10, green: 0.11, blue: 0.13))
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 9).fill(Color(red: 0.04, green: 0.66, blue: 0.75))
                Image(systemName: "bolt.fill").font(.system(size: 20, weight: .bold)).foregroundColor(.white)
            }
            .frame(width: 38, height: 38)
            VStack(alignment: .leading, spacing: 2) {
                Text("Halogen").font(.system(size: 18, weight: .bold)).foregroundColor(.white)
                Text("Native development environment").font(.system(size: 10)).foregroundColor(Color.white.opacity(0.48))
            }
            Spacer()
            Button(action: { model.newFile() }) { Label("New", systemImage: "doc") }.buttonStyle(QuietButtonStyle())
            Button(action: { model.openFile() }) { Label("Open", systemImage: "folder") }.buttonStyle(QuietButtonStyle())
            Button(action: { model.saveFile() }) { Label("Save", systemImage: "square.and.arrow.down") }.buttonStyle(QuietButtonStyle())
            Button(action: { model.saveFileAs() }) { Text("Save as") }.buttonStyle(QuietButtonStyle())
            Button(action: { model.checkProgram(); rightPanel = .console }) { Label("Check", systemImage: "checkmark.circle") }.buttonStyle(QuietButtonStyle())
            Button(action: { model.runProgram(); rightPanel = model.graphics.isEmpty ? .console : .graphics }) {
                Label("Run", systemImage: "play.fill")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 13)
                    .padding(.vertical, 8)
                    .background(Color(red: 0.02, green: 0.60, blue: 0.48))
                    .cornerRadius(7)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 11)
        .background(Color(red: 0.13, green: 0.14, blue: 0.16))
    }

    private func sectionHeader(title: String, subtitle: String) -> some View {
        HStack {
            Text(title).font(.system(size: 11, weight: .bold, design: .monospaced)).foregroundColor(Color.white.opacity(0.68))
            Spacer()
            Text(subtitle).font(.system(size: 11, design: .monospaced)).foregroundColor(Color.white.opacity(0.38))
        }
        .padding(.horizontal, 15)
        .frame(height: 38)
        .background(Color(red: 0.12, green: 0.13, blue: 0.15))
    }
}

struct QuietButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 11, weight: .medium))
            .foregroundColor(Color.white.opacity(configuration.isPressed ? 0.65 : 0.9))
            .padding(.horizontal, 9)
            .padding(.vertical, 7)
            .background(configuration.isPressed ? Color.white.opacity(0.10) : Color.white.opacity(0.045))
            .cornerRadius(6)
    }
}

struct ConsoleView: View {
    let text: String
    var body: some View {
        ScrollView {
            Text(text.isEmpty ? "Console is empty." : text)
                .font(.system(size: 12, weight: .regular, design: .monospaced))
                .foregroundColor(Color(red: 0.76, green: 0.88, blue: 0.80))
                .frame(maxWidth: .infinity, alignment: .topLeading)
                .textSelection(.enabled)
                .padding(14)
        }
        .background(Color(red: 0.08, green: 0.09, blue: 0.11))
    }
}

struct CodeEditorView: NSViewRepresentable {
    @Binding var text: String
    let onEdit: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeNSView(context: Context) -> NSScrollView {
        let scroll = NSScrollView(frame: .zero)
        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = true
        scroll.autohidesScrollers = true
        scroll.drawsBackground = true
        scroll.backgroundColor = NSColor(calibratedRed: 0.075, green: 0.085, blue: 0.10, alpha: 1)

        let editor = NSTextView(frame: .zero)
        editor.delegate = context.coordinator
        editor.string = text
        editor.isRichText = false
        editor.isSelectable = true
        editor.isEditable = true
        editor.usesFindBar = true
        editor.font = NSFont.monospacedSystemFont(ofSize: 14, weight: .regular)
        editor.textColor = NSColor(calibratedRed: 0.88, green: 0.90, blue: 0.93, alpha: 1)
        editor.backgroundColor = NSColor(calibratedRed: 0.075, green: 0.085, blue: 0.10, alpha: 1)
        editor.insertionPointColor = NSColor(calibratedRed: 0.25, green: 0.83, blue: 0.88, alpha: 1)
        editor.selectedTextAttributes = [.backgroundColor: NSColor(calibratedRed: 0.12, green: 0.27, blue: 0.31, alpha: 1)]
        editor.textContainerInset = NSSize(width: 14, height: 14)
        editor.isAutomaticQuoteSubstitutionEnabled = false
        editor.isAutomaticDashSubstitutionEnabled = false
        editor.isAutomaticTextReplacementEnabled = false
        editor.isAutomaticSpellingCorrectionEnabled = false
        editor.allowsUndo = true
        editor.minSize = NSSize(width: 0, height: 0)
        editor.maxSize = NSSize(width: .greatestFiniteMagnitude, height: .greatestFiniteMagnitude)
        editor.isVerticallyResizable = true
        editor.isHorizontallyResizable = true
        editor.autoresizingMask = [.width]
        editor.textContainer?.widthTracksTextView = false
        editor.textContainer?.containerSize = NSSize(width: .greatestFiniteMagnitude, height: .greatestFiniteMagnitude)
        scroll.documentView = editor
        return scroll
    }

    func updateNSView(_ scroll: NSScrollView, context: Context) {
        context.coordinator.parent = self
        guard let editor = scroll.documentView as? NSTextView, editor.string != text else { return }
        editor.string = text
    }

    final class Coordinator: NSObject, NSTextViewDelegate {
        var parent: CodeEditorView
        init(_ parent: CodeEditorView) { self.parent = parent }
        func textDidChange(_ notification: Notification) {
            guard let editor = notification.object as? NSTextView else { return }
            parent.text = editor.string
            parent.onEdit()
        }
    }
}
