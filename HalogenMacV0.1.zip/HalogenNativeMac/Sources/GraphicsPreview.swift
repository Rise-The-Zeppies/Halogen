import SwiftUI

struct GraphicsPreview: View {
    @ObservedObject var model: HalogenIDEModel

    var body: some View {
        VStack(spacing: 0) {
            GraphicsPreviewHeader(model: model)
            GraphicsPreviewCanvas(model: model)
        }
        .background(Color(red: 0.08, green: 0.09, blue: 0.11))
    }
}

private struct GraphicsPreviewHeader: View {
    @ObservedObject var model: HalogenIDEModel

    var body: some View {
        HStack {
            Text(model.graphicsTitle)
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(Color.white.opacity(0.66))

            Spacer()

            Text("\(Int(model.graphicsWidth)) × \(Int(model.graphicsHeight))")
                .font(.system(size: 10, design: .monospaced))
                .foregroundColor(Color.white.opacity(0.36))
        }
        .padding(.horizontal, 12)
        .frame(height: 32)
        .background(Color(red: 0.10, green: 0.11, blue: 0.13))
    }
}

private struct GraphicsPreviewCanvas: View {
    @ObservedObject var model: HalogenIDEModel

    var body: some View {
        GeometryReader { geometry in
            canvasContent(size: geometry.size)
        }
    }

    private func canvasContent(size: CGSize) -> some View {
        let canvasWidth = max(CGFloat(1), size.width)
        let canvasHeight = max(CGFloat(1), size.height)
        let designWidth = max(1.0, model.graphicsWidth)
        let designHeight = max(1.0, model.graphicsHeight)
        let scaleX = canvasWidth / CGFloat(designWidth)
        let scaleY = canvasHeight / CGFloat(designHeight)

        return ZStack(alignment: .topLeading) {
            HColor.color(model.graphicsBackground)

            ForEach(model.graphics) { item in
                GraphicPreviewItem(
                    item: item,
                    scaleX: scaleX,
                    scaleY: scaleY,
                    canvasWidth: canvasWidth,
                    canvasHeight: canvasHeight,
                    onButtonClick: { command in
                        model.graphicButtonClicked(command)
                    }
                )
            }

            if model.graphics.isEmpty {
                GraphicsPreviewPlaceholder()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .frame(width: canvasWidth, height: canvasHeight)
        .clipped()
        .contentShape(Rectangle())
        .onTapGesture {
            model.graphicsCanvasClicked()
        }
    }
}

private struct GraphicPreviewItem: View {
    let item: GraphicCommand
    let scaleX: CGFloat
    let scaleY: CGFloat
    let canvasWidth: CGFloat
    let canvasHeight: CGFloat
    let onButtonClick: (GraphicCommand) -> Void

    var body: some View {
        renderedItem
    }

    @ViewBuilder
    private var renderedItem: some View {
        switch item.kind {
        case .rectangle:
            rectangleView
        case .circle:
            circleView
        case .text:
            textView
        case .line:
            lineView
        case .button:
            buttonView
        }
    }

    private var rectangleView: some View {
        Rectangle()
            .fill(HColor.color(item.color))
            .frame(
                width: max(CGFloat(0), CGFloat(item.width) * scaleX),
                height: max(CGFloat(0), CGFloat(item.height) * scaleY)
            )
            .position(
                x: (CGFloat(item.x) + CGFloat(item.width) / 2) * scaleX,
                y: (CGFloat(item.y) + CGFloat(item.height) / 2) * scaleY
            )
    }

    private var circleView: some View {
        Circle()
            .fill(HColor.color(item.color))
            .frame(
                width: max(CGFloat(0), CGFloat(item.radius * 2) * scaleX),
                height: max(CGFloat(0), CGFloat(item.radius * 2) * scaleY)
            )
            .position(
                x: CGFloat(item.x) * scaleX,
                y: CGFloat(item.y) * scaleY
            )
    }

    private var textView: some View {
        Text(item.text)
            .font(.system(size: max(CGFloat(8), CGFloat(item.fontSize) * min(scaleX, scaleY))))
            .foregroundColor(HColor.color(item.color))
            .fixedSize()
            .offset(x: CGFloat(item.x) * scaleX, y: CGFloat(item.y) * scaleY)
    }

    private var lineView: some View {
        Path { path in
            path.move(to: CGPoint(x: CGFloat(item.x) * scaleX, y: CGFloat(item.y) * scaleY))
            path.addLine(to: CGPoint(x: CGFloat(item.x2) * scaleX, y: CGFloat(item.y2) * scaleY))
        }
        .stroke(
            HColor.color(item.color),
            style: StrokeStyle(
                lineWidth: max(CGFloat(1), CGFloat(item.width) * min(scaleX, scaleY)),
                lineCap: .round
            )
        )
        .frame(width: canvasWidth, height: canvasHeight)
    }

    private var buttonView: some View {
        Button(action: { onButtonClick(item) }) {
            Text(item.text)
                .font(.system(size: max(CGFloat(10), CGFloat(item.fontSize) * min(scaleX, scaleY)), weight: .semibold))
                .foregroundColor(.white)
                .frame(
                    width: max(CGFloat(44), CGFloat(item.width) * scaleX),
                    height: max(CGFloat(28), CGFloat(item.height) * scaleY)
                )
                .background(HColor.color(item.color))
                .cornerRadius(7)
        }
        .buttonStyle(PlainButtonStyle())
        .position(
            x: (CGFloat(item.x) + CGFloat(item.width) / 2) * scaleX,
            y: (CGFloat(item.y) + CGFloat(item.height) / 2) * scaleY
        )
    }
}

private struct GraphicsPreviewPlaceholder: View {
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: "rectangle.on.rectangle")
                .font(.system(size: 28))
                .foregroundColor(Color.white.opacity(0.25))

            Text("HalogenUI preview")
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(Color.white.opacity(0.5))

            Text("Run a .hg file that draws a window or shapes.")
                .font(.system(size: 10))
                .foregroundColor(Color.white.opacity(0.32))
        }
    }
}

enum HColor {
    static func color(_ input: String) -> Color {
        let named: [String: Color] = [
            "white": .white, "black": .black, "red": .red, "green": .green,
            "blue": .blue, "yellow": .yellow, "orange": .orange, "purple": .purple,
            "pink": .pink, "gray": .gray, "grey": .gray, "cyan": .cyan,
            "magenta": .pink, "clear": .clear
        ]

        let key = input.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if let color = named[key] {
            return color
        }

        let raw = key.hasPrefix("#") ? String(key.dropFirst()) : key
        guard (raw.count == 6 || raw.count == 3), let number = UInt64(raw, radix: 16) else {
            return Color(red: 0.8, green: 0.8, blue: 0.8)
        }

        if raw.count == 3 {
            let red = Double((number >> 8) & 0xF) / 15
            let green = Double((number >> 4) & 0xF) / 15
            let blue = Double(number & 0xF) / 15
            return Color(red: red, green: green, blue: blue)
        }

        let red = Double((number >> 16) & 0xFF) / 255
        let green = Double((number >> 8) & 0xFF) / 255
        let blue = Double(number & 0xFF) / 255
        return Color(red: red, green: green, blue: blue)
    }
}
