import SwiftUI

@main
struct HalogenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .frame(minWidth: 1040, minHeight: 700)
                .preferredColorScheme(.dark)
        }
    }
}
