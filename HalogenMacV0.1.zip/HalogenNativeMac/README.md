# Halogen Native for macOS — prototype 0.1

Halogen Native is a native Swift/SwiftUI macOS editor and interpreter for `.hg` files. The app code does **not** run on Python. The interpreter is implemented in Swift, and the first HalogenUI preview is drawn with SwiftUI.

**Important build note:** this workspace is Linux, so it cannot compile or verify a macOS `.app` binary. The project includes a build script which compiles `build/Halogen.app` when run on your Mac (macOS 12 Monterey or newer) with Apple's Swift compiler available.

## Build and launch on macOS 12 Monterey

1. Download and unzip this folder on your Mac.
2. If you do not already have Apple's developer tools, open Terminal and run `xcode-select --install`, then finish the Apple installer.
3. Double-click `build_app.command`. If macOS blocks the script on first open, Control-click it in Finder and choose **Open**.
4. The script compiles and signs locally (ad-hoc), creates `build/Halogen.app`, and opens it.
5. After building, you can move `build/Halogen.app` into Applications. If you change the Swift source, run `build_app.command` again.

The app is not notarized or signed with an Apple Developer ID. It is intended as a local development build.

## App icon and sharing the project

The project includes `AppIcon.icns` (used by the native macOS app) and `HalogenAppIcon.png` (1024×1024 master artwork). The build script copies the icon into `Halogen.app/Contents/Resources` and the bundle metadata references it.

For public releases, share the built app only after testing it on a clean Mac. This development build is ad-hoc signed and not notarized with an Apple Developer ID, so other users may see macOS security warnings. Public distribution generally needs proper Developer ID signing and Apple notarization for a smoother install experience.

## Included editor features

- Native macOS window, using SwiftUI and AppKit
- Source editor for `.hg` files
- Open, Save, Save as, and New actions
- Run button and console output
- A first-draft HalogenUI graphics preview
- A structure checker for `end`-terminated blocks
- Native dialog prompt for `ask("...")`

## Halogen v0.1 syntax implemented

```halogen
write("Hello!")

var("score") set 42
score get

str("word") = poop
word get

bool("ready") = T
ready get

ask("What is your name? ")

#/ This is a comment. \#

rpt 3:
    write("repeat")
end

if score > 10:
    write("big")
elif score == 10:
    write("ten")
else:
    write("small")
end

def greet(name):
    write("Hello, " + name)
end

greet("Halogen")
```

### Current behavior notes

- `x get` is a standalone command; it is not wrapped in `write()` or quotation marks.
- `var("x") set ...` declares or updates a number. Integers and decimals are in the same number category.
- `str("x") = poop` stores unquoted text when `poop` is not an existing variable. Quoted text is supported too.
- `bool("x") = T` accepts `T`/`t` and `F`/`f`.
- `ask("prompt")` opens a native input dialog and shows the entered response in the console. Storing the returned response in a variable is not part of the finalized syntax yet.
- `rpt`, `if`/`elif`/`else`, and `def` blocks close with `end`.
- Function parameters, `return`, numeric math, string concatenation, comparisons, `and`, `or`, and `not` are supported as initial language features.
- `Check` currently checks block structure and closing `end` markers. `Run` validates commands and expressions as it executes them.

## HalogenUI (first-draft syntax)

HalogenUI is intended to be Halogen's Pygame-like graphics library. The first native prototype draws into the HalogenUI panel inside the IDE; it does not yet launch a separate standalone graphics window.

```halogen
import HalogenUI

HalogenUI.window("My app", 800, 500, "#171923")
HalogenUI.fill("#171923")
HalogenUI.rect("#27c6da", 40, 80, 180, 100)
HalogenUI.circle("#ff5d8f", 320, 130, 45)
HalogenUI.text("Hello!", 40, 25, "white", 26)

def clicked():
    write("Button clicked!")
end

HalogenUI.button("Click me", 55, 300, 160, 50, clicked)
HalogenUI.run()
```

First-draft calls: `window`, `fill`, `rect`/`rectangle`, `circle`, `text`, `line`, `button`, `on_click`, `run`, `update`, `close`, `width`, `height`, and `is_open`. The preview uses the app's event loop, so `HalogenUI.run()` is a valid no-op lifecycle call for now. Buttons can call a previously defined no-argument Halogen function.

## Scope and next steps

This is a native starting point, not a finished programming platform yet. The next phase is to test the app on Monterey, refine the HalogenUI API with you, add syntax coloring and line numbers, and decide how `ask()` should store returned input values before expanding the language.
